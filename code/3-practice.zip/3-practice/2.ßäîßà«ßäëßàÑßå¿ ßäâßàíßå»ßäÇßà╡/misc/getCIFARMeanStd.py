from torchvision.datasets import CIFAR10

train_dataset=CIFAR10(root='./)